// src/components/orders/OrderItemsList.tsx
"use client";
import React from "react";
import { groupItemsByCategory, getCategoryColor, getCategoryOrder } from "@/utils/categoryMapping";
import { useOrderItemTracking } from "@/hooks/useOrderItemTracking";

interface OrderItemsListProps {
  orderId: string;
  items: any[];
  canEdit?: boolean;
  canRemove?: boolean;
  onEditItem?: (idx: number, patch: any) => void;
  onRemoveItem?: (idx: number) => void;
  noteOpen?: Record<string, boolean>;
  toggleNote?: (orderId: string, idx: number) => void;
  recipeLinks?: Record<string, string>;
  compact?: boolean; // For compact display in ClientsView
}

export default function OrderItemsList({
  orderId,
  items,
  canEdit = false,
  canRemove = false,
  onEditItem,
  onRemoveItem,
  noteOpen,
  toggleNote,
  recipeLinks,
  compact = false,
}: OrderItemsListProps) {
  const tracking = useOrderItemTracking();
  const groupedItems = groupItemsByCategory(items);

  const renderItem = (item: any, idx: number, category: string) => {
    const itemState = tracking.getItemState(orderId, idx);
    const isNoteOpen = noteOpen?.[`${orderId}:${idx}`] || false;
    const recipeLink = recipeLinks?.[item.title];

    // Status colors
    const statusColors = {
      pending: 'bg-gray-100 border-gray-300',
      partial: 'bg-yellow-50 border-yellow-300',
      almost: 'bg-orange-50 border-orange-300',
      done: 'bg-green-50 border-green-300',
    };

    const statusIcons = {
      pending: '⚪',
      partial: '🟡',
      almost: '🟠',
      done: '✅',
    };

    if (compact) {
      // Compact view for ClientsView
      return (
        <div
          key={idx}
          className={`flex items-center justify-between gap-2 px-2 py-1 rounded border ${statusColors[itemState.status]}`}
          onClick={() => tracking.cycleCompletionStatus(orderId, idx, item.qty)}
        >
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <span className="text-lg">{statusIcons[itemState.status]}</span>
            {recipeLink ? (
              <a
                href={`/recipes/${recipeLink}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="font-medium text-blue-600 hover:text-blue-700 hover:underline truncate"
                title="פתח מתכון"
              >
                {item.title}
              </a>
            ) : (
              <span className="font-medium text-gray-900 truncate">{item.title}</span>
            )}
          </div>
          <span className="text-sm font-bold text-gray-700 whitespace-nowrap">
            × {item.qty}
          </span>
        </div>
      );
    }

    // Full view for DayOrdersList
    return (
      <div
        key={idx}
        className={`rounded-lg border-2 p-3 transition-all ${statusColors[itemState.status]}`}
      >
        <div className="flex items-center justify-between gap-2">
          {/* Left side: Status + Title */}
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <button
              onClick={() => tracking.cycleCompletionStatus(orderId, idx, item.qty)}
              className="text-2xl hover:scale-110 transition-transform flex-shrink-0"
              title="שנה סטטוס"
            >
              {statusIcons[itemState.status]}
            </button>

            <div className="flex-1 min-w-0">
              {canEdit ? (
                <input
                  type="text"
                  value={item.title}
                  onChange={(e) => onEditItem?.(idx, { title: e.target.value })}
                  className="w-full px-2 py-1 rounded border border-gray-300 font-medium text-gray-900"
                />
              ) : recipeLink ? (
                <a
                  href={`/recipes/${recipeLink}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="text-sm font-semibold text-blue-600 hover:text-blue-700 hover:underline"
                  title="פתח מתכון"
                >
                  {item.title}
                </a>
              ) : (
                <span className="text-sm font-semibold text-gray-900">{item.title}</span>
              )}
            </div>
          </div>

          {/* Right side: Quantity + Actions */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {canEdit ? (
              <input
                type="number"
                value={item.qty}
                onChange={(e) => {
                  const newQty = Number(e.target.value) || 1;
                  onEditItem?.(idx, { qty: newQty });
                  tracking.updateCompletedQty(orderId, idx, itemState.completed, newQty);
                }}
                className="w-16 px-2 py-1 rounded border border-gray-300 text-center font-bold"
              />
            ) : (
              <span className="text-xl font-bold text-gray-700">× {item.qty}</span>
            )}

            {toggleNote && (
              <button
                onClick={() => toggleNote(orderId, idx)}
                className={`px-2 py-1 rounded text-xs font-medium transition-all ${
                  isNoteOpen
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
                title={isNoteOpen ? 'סגור הערה' : 'פתח הערה'}
              >
                {isNoteOpen ? '📝 סגור' : '📝'}
              </button>
            )}

            {canRemove && (
              <button
                onClick={() => onRemoveItem?.(idx)}
                className="px-2 py-1 rounded bg-red-500 text-white hover:bg-red-600 transition-all text-xs font-medium"
                title="מחק פריט"
              >
                🗑️
              </button>
            )}
          </div>
        </div>

        {/* Notes section */}
        {isNoteOpen && (
          <div className="mt-2 pt-2 border-t border-gray-300">
            {canEdit ? (
              <textarea
                value={item.notes || ''}
                onChange={(e) => onEditItem?.(idx, { notes: e.target.value })}
                placeholder="הערות..."
                className="w-full px-2 py-1 rounded border border-gray-300 text-sm resize-none"
                rows={2}
              />
            ) : item.notes ? (
              <div className="text-sm text-gray-600 whitespace-pre-wrap">{item.notes}</div>
            ) : (
              <div className="text-sm text-gray-400 italic">אין הערות</div>
            )}

            {/* Missing note */}
            {itemState.missingNote && (
              <div className="mt-2 p-2 bg-orange-100 border border-orange-300 rounded text-sm text-orange-800">
                <strong>חסר:</strong> {itemState.missingNote}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-3">
      {getCategoryOrder().map((category) => {
        const categoryItems = groupedItems[category];
        if (!categoryItems || categoryItems.length === 0) return null;

        const categoryColor = getCategoryColor(category);

        return (
          <div key={category} className="rounded-lg overflow-hidden border-2" style={{ borderColor: categoryColor }}>
            {/* Category Header */}
            <div
              className="px-3 py-2 font-bold text-center"
              style={{ backgroundColor: categoryColor, color: '#1f2937' }}
            >
              {category}
            </div>

            {/* Items */}
            <div className={compact ? "p-2 space-y-1" : "p-3 space-y-2"} style={{ backgroundColor: `${categoryColor}15` }}>
              {categoryItems.map((item: any) => {
                const originalIdx = items.findIndex((i) => i === item);
                return renderItem(item, originalIdx, category);
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}