// src/components/orders/OrderCard.tsx
"use client";
import React, { useState } from "react";
import OrderItemsList from "./OrderItemsList";
import { getTextColor } from "@/utils/colorHelpers";
import { useOrderTracking } from "./tracking/OrderTrackingContext";

interface OrderCardProps {
  order: any;
  clientColor: string;
  canEdit?: boolean;
  canDelete?: boolean;
  canRemove?: boolean;
  canAddItems?: boolean;
  onEditItem?: (orderId: string, idx: number, patch: any) => void;
  onRemoveItem?: (orderId: string, idx: number) => void;
  onDeleteOrder?: (orderId: string) => void;
  onAddItem?: (orderId: string) => void;
  onEditColor?: (clientName: string, currentColor: string) => void;
  noteOpen?: Record<string, boolean>;
  toggleNote?: (orderId: string, idx: number) => void;
  recipeLinks?: Record<string, string>;
  compact?: boolean;
  showDate?: boolean;
}

export default function OrderCard({
  order,
  clientColor,
  canEdit = false,
  canDelete = false,
  canRemove = false,
  canAddItems = false,
  onEditItem,
  onRemoveItem,
  onDeleteOrder,
  onAddItem,
  onEditColor,
  noteOpen,
  toggleNote,
  recipeLinks,
  compact = false,
  showDate = true,
}: OrderCardProps) {
  const [showHistory, setShowHistory] = useState(false);

  // Try to get tracking context
  let tracking;
  try {
    tracking = useOrderTracking();
  } catch {
    tracking = null;
  }

  const textColor = getTextColor(clientColor);
  const orderDate = order.eventDate ? new Date(order.eventDate) : null;

  // Get order history logs (only if tracking exists and has this method)
  const orderLogs = (tracking && typeof tracking.getOrderLogs === 'function') 
    ? tracking.getOrderLogs(order.__id!) 
    : [];

  return (
    <div
      className={`rounded-xl overflow-hidden shadow-lg border-4 transition-all hover:shadow-2xl ${
        compact ? '' : 'hover:scale-[1.02]'
      }`}
      style={{ borderColor: clientColor }}
    >
      {/* Header */}
      <div
        className="px-4 py-3 flex items-center justify-between"
        style={{ backgroundColor: clientColor, color: textColor }}
      >
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {onEditColor && (
            <button
              onClick={() => onEditColor(order.clientName, clientColor)}
              className="w-6 h-6 rounded-full border-2 border-white hover:scale-110 transition-transform flex-shrink-0"
              style={{ backgroundColor: clientColor }}
              title="שנה צבע"
            />
          )}

          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-lg truncate">{order.clientName}</h3>
            {showDate && orderDate && (
              <div className="text-sm opacity-90">
                {orderDate.toLocaleDateString('he-IL', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                })}
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {orderLogs.length > 0 && (
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="px-2 py-1 rounded bg-white/20 hover:bg-white/30 transition-all text-xs font-medium"
              title={showHistory ? 'הסתר היסטוריה' : 'הצג היסטוריה'}
            >
              📜 {orderLogs.length}
            </button>
          )}

          {canAddItems && onAddItem && (
            <button
              onClick={() => onAddItem(order.__id!)}
              className="px-2 py-1 rounded bg-white/20 hover:bg-white/30 transition-all text-xs font-medium"
              title="הוסף פריט"
            >
              ➕
            </button>
          )}

          {canDelete && onDeleteOrder && (
            <button
              onClick={() => {
                if (confirm(`למחוק הזמנה של ${order.clientName}?`)) {
                  onDeleteOrder(order.__id!);
                }
              }}
              className="px-2 py-1 rounded bg-red-500/80 hover:bg-red-600 transition-all text-xs font-medium text-white"
              title="מחק הזמנה"
            >
              🗑️
            </button>
          )}
        </div>
      </div>

      {/* Order Notes */}
      {order.orderNotes && (
        <div className="px-4 py-2 bg-yellow-50 border-b border-yellow-200 text-sm text-gray-700">
          <strong>הערות:</strong> {order.orderNotes}
        </div>
      )}

      {/* History */}
      {showHistory && orderLogs.length > 0 && (
        <div className="px-4 py-3 bg-blue-50 border-b border-blue-200">
          <div className="text-sm font-bold text-blue-800 mb-2">📜 היסטוריית שינויים</div>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {orderLogs.map((log: any) => {
              // Group changes by item
              const itemChangesMap = new Map<number, {
                title: string;
                status?: { old: string; new: string };
                completed?: { old: number; new: number };
                missingNote?: string;
                note?: boolean;
              }>();

              log.changes?.forEach((change: any) => {
                if (!itemChangesMap.has(change.itemIndex)) {
                  itemChangesMap.set(change.itemIndex, { title: change.itemTitle });
                }
                const item = itemChangesMap.get(change.itemIndex)!;

                if (change.type === 'status') {
                  item.status = { old: change.oldValue, new: change.newValue };
                } else if (change.type === 'completed') {
                  item.completed = { old: change.oldValue, new: change.newValue };
                } else if (change.type === 'missingNote') {
                  item.missingNote = change.newValue;
                } else if (change.type === 'note') {
                  item.note = true;
                }
              });

              return (
                <div key={log.id} className="bg-white rounded-lg px-3 py-2 border border-blue-200 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-blue-700 text-sm">👤 {log.userName}</span>
                    <span className="text-xs text-gray-500">
                      {log.timestamp.toLocaleString('he-IL', {
                        day: '2-digit',
                        month: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  {itemChangesMap.size > 0 && (
                    <div className="space-y-1">
                      {Array.from(itemChangesMap.entries()).map(([idx, changes]) => (
                        <div key={idx} className="text-xs text-gray-700">
                          <span className="font-medium">{changes.title}:</span>
                          {changes.status && (
                            <span className="mr-1">
                              {changes.status.old} → {changes.status.new}
                            </span>
                          )}
                          {changes.completed && (
                            <span className="mr-1">
                              כמות: {changes.completed.old} → {changes.completed.new}
                            </span>
                          )}
                          {changes.missingNote && (
                            <span className="mr-1 text-orange-600">חסר: {changes.missingNote}</span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Items List */}
      <div className={compact ? "p-3" : "p-4"}>
        <OrderItemsList
          orderId={order.__id!}
          items={order.items || []}
          canEdit={canEdit}
          canRemove={canRemove}
          onEditItem={onEditItem ? (idx, patch) => onEditItem(order.__id!, idx, patch) : undefined}
          onRemoveItem={onRemoveItem ? (idx) => onRemoveItem(order.__id!, idx) : undefined}
          noteOpen={noteOpen}
          toggleNote={toggleNote}
          recipeLinks={recipeLinks}
          compact={compact}
        />
      </div>
    </div>
  );
}