declare module "nosleep.js" {
  export default class NoSleep {
    enable(): void;
    disable(): void;
  }
}
