import MigrateClients from "@/scripts/MigrateClients";

export default function MigratePage() {
  return <MigrateClients />;
}