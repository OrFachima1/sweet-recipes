export default function Loading() {
  return <div className="p-6">טוען מצב שקילה…</div>;
}
