// src/hooks/useOrderItemTracking.ts
import { useState, useCallback } from 'react';
import { useOrderTracking } from '@/components/orders/tracking/OrderTrackingContext';

interface ItemState {
  completed: number;
  status: 'pending' | 'partial' | 'almost' | 'done';
  missingNote: string;
}

export function useOrderItemTracking() {
  // Try to use context-based tracking if available
  let contextTracking;
  try {
    contextTracking = useOrderTracking();
  } catch {
    contextTracking = null;
  }

  // Local fallback state
  const [localState, setLocalState] = useState<Record<string, ItemState>>({});

  const getItemKey = useCallback((orderId: string, itemIdx: number) => {
    return `${orderId}:${itemIdx}`;
  }, []);

  const getItemState = useCallback((orderId: string, itemIdx: number): ItemState => {
    if (contextTracking) {
      return contextTracking.getItemState(orderId, itemIdx);
    }
    const key = getItemKey(orderId, itemIdx);
    return localState[key] || { completed: 0, status: 'pending' as const, missingNote: '' };
  }, [contextTracking, localState, getItemKey]);

  const updateItemState = useCallback((orderId: string, itemIdx: number, newState: ItemState) => {
    if (contextTracking) {
      contextTracking.updateItemState(orderId, itemIdx, newState);
    } else {
      const key = getItemKey(orderId, itemIdx);
      setLocalState(prev => ({ ...prev, [key]: newState }));
    }
  }, [contextTracking, getItemKey]);

  const cycleCompletionStatus = useCallback((orderId: string, itemIdx: number, totalQty: number) => {
    const current = getItemState(orderId, itemIdx);
    
    let newState: ItemState;
    if (current.status === 'pending') {
      newState = { completed: totalQty, status: 'done', missingNote: '' };
    } else if (current.status === 'done') {
      newState = { completed: totalQty, status: 'almost', missingNote: '' };
    } else if (current.status === 'almost') {
      newState = { completed: 0, status: 'pending', missingNote: '' };
    } else {
      newState = { completed: 0, status: 'pending', missingNote: '' };
    }
    
    updateItemState(orderId, itemIdx, newState);
  }, [getItemState, updateItemState]);

  const updateCompletedQty = useCallback((orderId: string, itemIdx: number, completed: number, totalQty: number) => {
    const status: ItemState['status'] = 
      completed === 0 ? 'pending' : 
      completed === totalQty ? 'done' : 
      completed >= totalQty * 0.9 ? 'almost' : 
      'partial';
    
    updateItemState(orderId, itemIdx, { completed, status, missingNote: '' });
  }, [updateItemState]);

  const updateMissingNote = useCallback((orderId: string, itemIdx: number, note: string) => {
    const current = getItemState(orderId, itemIdx);
    updateItemState(orderId, itemIdx, { ...current, missingNote: note });
  }, [getItemState, updateItemState]);

  return {
    getItemState,
    updateItemState,
    cycleCompletionStatus,
    updateCompletedQty,
    updateMissingNote,
    hasContextTracking: !!contextTracking,
  };
}