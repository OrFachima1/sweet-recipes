// src/hooks/useOrdersFirebase.ts
import { useEffect, useCallback } from 'react';
import { db } from '@/lib/firebase';
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  serverTimestamp,
  query,
  orderBy as firestoreOrderBy,
  writeBatch,
} from 'firebase/firestore';
import { setCategoryConfig } from '@/utils/categoryMapping';
import type { IngestJsonOrder } from '@/types/orders';

interface UseOrdersFirebaseProps {
  user: any;
  isManager: boolean;
  getClientColor: (clientName: string) => string;
  setOrders: (orders: IngestJsonOrder[]) => void;
  orders: IngestJsonOrder[];
  settings: any;
  setMenuOptions: (options: string[]) => void;
}

export function useOrdersFirebase({
  user,
  isManager,
  getClientColor,
  setOrders,
  orders,
  settings,
  setMenuOptions,
}: UseOrdersFirebaseProps) {
  
  // ===== Load Orders from Firestore =====
  useEffect(() => {
    if (!user) return;
    let isSubscribed = true;

    const ordersCol = collection(db, "orders");
    const q = query(ordersCol, firestoreOrderBy("createdAt", "desc"));

    const unsub = onSnapshot(q, (snap) => {
      if (!isSubscribed) return;

      const list = snap.docs.map((d) => {
        const data = d.data();
        return {
          __id: d.id,
          orderId: data.orderId,
          clientName: data.clientName,
          clientColor: getClientColor(data.clientName),
          eventDate: data.eventDate,
          status: data.status,
          items: data.items || [],
          orderNotes: data.orderNotes,
          totalSum: data.totalSum,
          currency: data.currency,
          source: data.source,
          meta: data.meta,
          createdAt: data.createdAt,
        } as IngestJsonOrder;
      });

      setOrders(list);
    }, (err) => {
      console.error("Failed loading orders", err);
    });

    return () => {
      isSubscribed = false;
      unsub();
    };
  }, [user, getClientColor, setOrders]);

  // ===== Load Settings from Firestore =====
  useEffect(() => {
    if (!user) return;

    const settingsDoc = doc(db, "orderSettings", "main");
    const categoryDoc = doc(db, "orderSettings", "categoryConfig");

    const unsub1 = onSnapshot(settingsDoc, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        settings.updateMapping(data.mapping || {});
        settings.updateIgnored(data.ignored || []);
      }
    });

    const unsub2 = onSnapshot(categoryDoc, (snap) => {
      if (snap.exists()) {
        setCategoryConfig(snap.data());
      }
    });

    return () => {
      unsub1();
      unsub2();
    };
  }, [user, settings]);

  // ===== Load Category Config =====
  useEffect(() => {
    if (!user) return;

    const categoryDoc = doc(db, "orderSettings", "categoryConfig");
    const unsub = onSnapshot(categoryDoc, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        const config = {
          items: data.items || {},
          itemMapping: data.itemMapping || {}
        };

        settings.updateCategoryConfig(config);
        setCategoryConfig(config);
      }
    });

    return () => unsub();
  }, [user, settings]);

  // ===== Load Recipe Links =====
  useEffect(() => {
    if (!user) return;

    const recipeLinksDoc = doc(db, "orderSettings", "recipeLinks");
    const unsub = onSnapshot(recipeLinksDoc, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        settings.updateRecipeLinks(data.links || {});
      } else {
        settings.updateRecipeLinks({});
      }
    });

    return () => unsub();
  }, [user, settings]);

  // ===== Load Menu from Firestore =====
  useEffect(() => {
    if (!user) return;

    const menuDoc = doc(db, "orderSettings", "menu");
    const unsub = onSnapshot(menuDoc, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        const menuArray = data.items || [];
        setMenuOptions(menuArray);
      } else {
        setMenuOptions([]);
      }
    }, (err) => {
      console.error("Failed loading menu", err);
      setMenuOptions([]);
    });

    return () => unsub();
  }, [user, setMenuOptions]);

  // ===== Persist Orders to Firestore =====
  const persist = useCallback(async (next: IngestJsonOrder[]) => {
    if (!user || !isManager) {
      return;
    }

    try {
      const batch = writeBatch(db);

      // Filter orders without __id
      const validOrders = next.filter(o => o.__id);

      if (validOrders.length === 0) {
        return;
      }

      // Delete removed orders (compare with current orders)
      const currentIds = new Set(validOrders.map(o => o.__id));
      const deletedIds = orders
        .filter(o => o.__id && !currentIds.has(o.__id))
        .map(o => o.__id!);

      for (const id of deletedIds) {
        batch.delete(doc(db, "orders", id));
      }

      // Update/create orders
      for (const order of validOrders) {
        const orderDoc = doc(db, "orders", order.__id!);

        // Clean undefined → null
        const cleanData: any = {
          orderId: order.orderId ?? null,
          clientName: order.clientName ?? null,
          clientColor: order.clientColor || getClientColor(order.clientName),
          eventDate: order.eventDate ?? null,
          status: order.status ?? "new",
          items: (order.items || []).map(item => ({
            title: item.title ?? null,
            qty: typeof item.qty === 'number' ? item.qty : 1,
            unit: item.unit ?? null,
            notes: item.notes ?? null,
          })),
          orderNotes: order.orderNotes ?? null,
          totalSum: typeof order.totalSum === 'number' ? order.totalSum : null,
          currency: order.currency ?? null,
          source: order.source ?? null,
          meta: order.meta ?? null,
          createdAt: serverTimestamp(),
        };

        batch.set(orderDoc, cleanData);
      }

      await batch.commit();

    } catch (e: any) {
      console.error("שגיאה בשמירה:", e);
      alert(`שגיאה בשמירה ל-Firebase: ${e?.message || e?.code || 'Unknown error'}`);
    }
  }, [user, isManager, orders, getClientColor]);

  // ===== Save Settings to Firestore =====
  const saveSettings = useCallback(async (
    newMapping: Record<string, string>,
    newIgnored: string[]
  ) => {
    if (!user) return;
    try {
      await setDoc(doc(db, "orderSettings", "main"), {
        mapping: newMapping,
        ignored: newIgnored,
        updatedAt: serverTimestamp(),
      });
    } catch (e) {
      console.error("Failed saving settings", e);
    }
  }, [user]);

  return {
    persist,
    saveSettings,
  };
}